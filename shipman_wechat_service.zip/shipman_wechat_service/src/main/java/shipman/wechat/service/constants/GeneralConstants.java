package shipman.wechat.service.constants;

public class GeneralConstants {

  public static final String TOKEN = "lkc_lzm";
  public static final String APP_ID = "wx6751f39a70584592";
  public static final String APP_SECRET = "386aec4ef264680adbb5aebc18b3b267";
  public static final String GRANT_TYPE = "client_credential";
  public static String ACCESS_TOKEN;
}
