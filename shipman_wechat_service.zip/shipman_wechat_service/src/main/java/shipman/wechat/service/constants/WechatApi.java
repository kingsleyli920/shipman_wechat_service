package shipman.wechat.service.constants;

public class WechatApi {

  public static final String GET_ACCESS_TOKEN = "https://api.weixin.qq.com/cgi-bin/token";

}
