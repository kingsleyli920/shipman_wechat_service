package shipman.wechat.service.entity.textEntities;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Data;

//lobkok
@Data
@JacksonXmlRootElement(localName = "xml")
public class TextMessageResp {
    @JacksonXmlCData
    @JacksonXmlProperty(localName = "ToUserName")
    private String toUser;
    @JacksonXmlCData
    @JacksonXmlProperty(localName = "FromUserName")
    private String fromUser;
    @JacksonXmlCData
    @JacksonXmlProperty(localName = "CreateTime")
    private String createTime;
    @JacksonXmlCData
    @JacksonXmlProperty(localName = "MsgType")
    private String msgType="text";
    @JacksonXmlCData
    @JacksonXmlProperty(localName = "Content")
    private String content;

}
