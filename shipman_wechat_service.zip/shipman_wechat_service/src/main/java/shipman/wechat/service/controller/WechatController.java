package shipman.wechat.service.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import shipman.wechat.service.constants.WechatApi;
import shipman.wechat.service.service.MsgService;
import shipman.wechat.service.service.WechatService;
import shipman.wechat.service.util.HttpUtils;

@RestController
@Slf4j
@RequestMapping(path = "/wx")
public class WechatController {

  private static final Gson gson = new Gson();

  @Resource
  WechatService wechatService;
  @Resource
  HttpUtils httpUtils;
  @Resource
  MsgService msgService;

  /**
   * 验证接口的接口，微信测试号管理，接口配置信息中调用。
   *
   * @param request
   * @param response
   * @return
   */
  @GetMapping("/api")
  public String get(HttpServletRequest request, HttpServletResponse response) {
    String signature = request.getParameter("signature");
    String timestamp = request.getParameter("timestamp");
    String nonce = request.getParameter("nonce");
    String echostr = request.getParameter("echostr");
    log.info("checkauth");
    if (wechatService.checkAuth(timestamp, nonce, signature)) {
      log.info("验证成功");
      ServletOutputStream out = null;
      try {
        out = response.getOutputStream();
        out.print(echostr);
        out.flush();
        out.close();
        log.info("接入成功");
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return "";
  }

  /**
   * 接收微信各种请求的接口
   *
   * @return
   */
  @PostMapping(value = "/api", produces = "application/xml;charset=utf8")
  public Object getMsg(@RequestBody String data) {
    return msgService.getResp(data);
  }

  /**
   * 获取accessToken
   *
   * @param grantType client_credential
   * @param appID
   * @param secret
   * @param request
   * @param response
   * @return
   */
  @GetMapping("/accessToken")
  public JsonObject accessToken(
      @RequestParam("grantType") String grantType,
      @RequestParam("appID") String appID,
      @RequestParam("secret") String secret,
      HttpServletRequest request,
      HttpServletResponse response

  ) {
    JsonObject resp = new JsonObject();
    try {
      request.setCharacterEncoding("utf8");
      response.setCharacterEncoding("utf8");
      Map<String, Object> params = new HashMap<>();
      params.put("grant_type", grantType);
      params.put("appid", appID);
      params.put("secret", secret);
      resp = gson.fromJson(httpUtils.Get(WechatApi.GET_ACCESS_TOKEN, params), JsonObject.class);

    } catch (Exception e) {
      e.printStackTrace();
    }
    return resp;
  }

  @PostMapping("/createMenu")
  public String createMenu() {
    return wechatService.createMenu();
  }
}
