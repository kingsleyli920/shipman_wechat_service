package shipman.wechat.service.entity;

import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author kunchengli
 */
@Getter
@Setter
@ToString
public class MenuButton extends BaseButton {

  private List<BaseButton> sub_button;

  public MenuButton(String name) {
    super(name);
  }
}
