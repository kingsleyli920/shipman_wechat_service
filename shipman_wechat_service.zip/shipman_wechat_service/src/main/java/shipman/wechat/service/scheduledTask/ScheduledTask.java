package shipman.wechat.service.scheduledTask;

import static shipman.wechat.service.constants.GeneralConstants.APP_ID;
import static shipman.wechat.service.constants.GeneralConstants.APP_SECRET;
import static shipman.wechat.service.constants.GeneralConstants.GRANT_TYPE;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import shipman.wechat.service.constants.GeneralConstants;
import shipman.wechat.service.constants.WechatApi;
import shipman.wechat.service.util.HttpUtils;

@Service
public class ScheduledTask {

  private static Gson gson = new Gson();
  @Resource
  HttpUtils httpUtils;
}
