package shipman.wechat.service.constants;

public class UrlConstants {

  public static final String createMenu = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=";
}
