package shipman.wechat.service.service;

import com.baidu.aip.ocr.AipOcr;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import shipman.wechat.service.constants.BaiduApiConstants;
import shipman.wechat.service.entity.BaseButton;
import shipman.wechat.service.entity.ClickButton;
import shipman.wechat.service.entity.MenuButton;
import shipman.wechat.service.entity.PicOrAlbumButton;
import shipman.wechat.service.entity.textEntities.TextMessageResp;

@Service
@Slf4j
public class MsgService {

  private static final Gson gson = new Gson();
  XmlMapper xmlMapper;
  @Resource
  RestTemplate restTemplate;
  AipOcr baiduClient = new AipOcr(BaiduApiConstants.APP_ID, BaiduApiConstants.API_KEY, BaiduApiConstants.SECRET_KEY);

  // private

  public Object getResp(String data) {
    //用户发过来的是什么消息
    log.info("getResp => data: {}", data);
    Document document = null;
    try {
      document = DocumentHelper.parseText(data);
    } catch (DocumentException e) {
      e.printStackTrace();
    }
    assert document != null;
    Element root = document.getRootElement();
    List<Element> elements = null;
    if (root != null) {
      elements = root.elements();
    } else {
      return null;
    }
    Map<String, String> map = new HashMap<>();
    for (Element e : elements) {
      map.put(e.getName(), e.getStringValue());
    }
    String msgType = map.get("MsgType");
    switch (msgType) {
      case "text":
        return dealText(map);
      case "image":
        return dealImage(map);
      case "voice":

        break;
      case "video":

        break;
      case "shortvideo":

        break;
      case "location":

        break;
      case "link":

        break;
      case "event":

        break;
      default:
        break;
    }

    return null;
  }

  /**
   * 处理图片消息
   */
  private Object dealImage(Map<String, String> map) {
    TextMessageResp tm = new TextMessageResp();
    StringBuilder contents = new StringBuilder();
    tm.setToUser(map.get("FromUserName"));
    tm.setFromUser(map.get("ToUserName"));
    tm.setCreateTime(System.currentTimeMillis() / 1000 + "");

    String path = map.get("PicUrl");
    log.info("dealImage => path: {}", path);
    JSONObject res = baiduClient.basicGeneral(path, new HashMap<>());
    log.info("dealImage => res: {}", res);
    contents.append(res.toString(2));
    tm.setContent(contents.toString());
    return tm;
  }

  /**
   * 处理文件消息
   */
  private Object dealText(Map<String, String> map) {
    TextMessageResp tm = new TextMessageResp();
    tm.setContent("您发的的文本消息");
    tm.setToUser(map.get("FromUserName"));
    tm.setFromUser(map.get("ToUserName"));
    tm.setCreateTime(System.currentTimeMillis() / 1000 + "");
    return tm;
  }
}
