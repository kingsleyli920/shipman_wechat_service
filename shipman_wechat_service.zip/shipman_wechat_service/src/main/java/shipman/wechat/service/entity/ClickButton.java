package shipman.wechat.service.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author kunchengli
 */
@Getter
@Setter
@ToString
public class ClickButton extends BaseButton {

  private String type = "click";
  private String key;

  public ClickButton(String name, String key) {
    super(name);
    this.key = key;
  }
}
