package shipman.wechat.service.constants;

public class BaiduApiConstants {
  public static final String APP_ID = "23651602";
  public static final String API_KEY = "zRyoolB8RehXrsLu0BqBbL56";
  public static final String SECRET_KEY = "UKWxGNjsekcDfKosqUnV0UuebFuVSRq9";
}
