package shipman.wechat.service.service;

import static shipman.wechat.service.constants.GeneralConstants.ACCESS_TOKEN;
import static shipman.wechat.service.constants.GeneralConstants.APP_ID;
import static shipman.wechat.service.constants.GeneralConstants.APP_SECRET;
import static shipman.wechat.service.constants.GeneralConstants.GRANT_TYPE;
import static shipman.wechat.service.constants.GeneralConstants.TOKEN;

import com.baidu.aip.ocr.AipOcr;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import shipman.wechat.service.constants.UrlConstants;
import shipman.wechat.service.constants.WechatApi;
import shipman.wechat.service.entity.BaseButton;
import shipman.wechat.service.entity.ClickButton;
import shipman.wechat.service.entity.MenuButton;
import shipman.wechat.service.entity.PicOrAlbumButton;
import shipman.wechat.service.util.HttpUtils;

/**
 * @author kunchengli
 */
@Service
@Slf4j
public class WechatService implements InitializingBean {

  private static final Gson gson = new Gson();
  @Resource
  HttpUtils httpUtils;
  @Resource
  MsgService msgService;

  // private
  private static String sha1(String src) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("sha1");
      byte[] digest = messageDigest.digest(src.getBytes());

      StringBuilder stringBuilder = new StringBuilder();
      char[] chars = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e',
          'f'};
      for (byte b : digest) {
        stringBuilder.append(chars[(b >> 4) & 15]);
        stringBuilder.append(chars[b & 15]);
      }
      return stringBuilder.toString();
    } catch (NoSuchAlgorithmException e) {
      e.printStackTrace();
    }
    return "";
  }

  public Boolean checkAuth(String timestamp, String nonce, String signature) {

    String[] params = new String[]{TOKEN, timestamp, nonce};
    Arrays.sort(params);
    String mySignature = sha1(params[0] + params[1] + params[2]);

    return mySignature.equals(signature);
  }
  //Scheduled task

  public String createMenu() {
    List<BaseButton> menu = this.buildMenu();
    Map<String, Object> params = new HashMap<>();
    params.put("button", menu);
    String url = UrlConstants.createMenu + ACCESS_TOKEN;
    String resp = httpUtils.JPost(url, params);
    return resp;
  }

  @Scheduled(cron = "0 0 0/2 * * ?")
  public JsonObject accessToken() {
    JsonObject resp = new JsonObject();
    try {
      Map<String, Object> params = new HashMap<>();
      params.put("grant_type", GRANT_TYPE);
      params.put("appid", APP_ID);
      params.put("secret", APP_SECRET);
      resp = gson.fromJson(httpUtils.Get(WechatApi.GET_ACCESS_TOKEN, params), JsonObject.class);
      if (resp.has("access_token")) {
        ACCESS_TOKEN = resp.get("access_token").getAsString();
      }
      log.info("accessToken => ACCESS_TOKEN: {}", ACCESS_TOKEN);
    } catch (Exception e) {
      log.error("resp is : {} exception is : {}", resp, e.getMessage());
    }
    return resp;
  }


  @Override
  public void afterPropertiesSet() {
    this.accessToken();
  }

  // private
  /**
   * 创建菜单
   */
  private List<BaseButton> buildMenu() {
    List<BaseButton> allButtons = new ArrayList<>();
    BaseButton clickButton = new ClickButton("荣誉中心", "荣誉中心");
    BaseButton subClickButton1 = new PicOrAlbumButton("上传海员船员适任证书", "上传海员船员适任证书");
    BaseButton subClickButton2 = new ClickButton("请求客服", "请求客服");
    BaseButton subClickButton3 = new PicOrAlbumButton("上传图片", "上传图片");
    MenuButton subMenu = new MenuButton("认证中心");
    List<BaseButton> sub_button = new ArrayList<>();
    sub_button.add(subClickButton1);
    sub_button.add(subClickButton2);
    sub_button.add(subClickButton3);
    subMenu.setSub_button(sub_button);
    allButtons.add(clickButton);
    allButtons.add(subMenu);
    log.info("allButtons: {}", allButtons);
    return allButtons;
  }
}
