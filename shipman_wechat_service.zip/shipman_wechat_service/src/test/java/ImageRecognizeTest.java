public class ImageRecognizeTest {

  //
//  public static void main(String[] args) {
//    AipOcr client = new AipOcr("23651602", "zRyoolB8RehXrsLu0BqBbL56", "UKWxGNjsekcDfKosqUnV0UuebFuVSRq9");
//
//    String path1 = "/Users/kunchengli/Desktop/test1.jpg";
//    JSONObject res1 = client.basicGeneral(path1, new HashMap<>());
//    System.out.println(res1.toString(2));
//
//
//    HashMap<String, String> options = new HashMap<String, String>();
//    options.put("detect_direction", "false");
//    options.put("detect_risk", "true");
//
//    String idCardSide = "front";
//    String path2 = "/Users/kunchengli/Desktop/test2.jpg";
//    JSONObject res2 = client.idcard(path2, idCardSide, options);
//    System.out.println(res2.toString(2));
//
//    String templateSign = "f2b2f2912c7882d96861c3dd1ade6aec";
//    HashMap<String, String> opts = new HashMap<>();
//    opts.put("templateSign", templateSign);
//    String image = "/Users/kunchengli/Desktop/test3.jpg";
//    JSONObject res = client.custom(image, opts);
//    System.out.println(res.toString(2));
//  }
}
